# Actividad 3 (Despliegue de Regresión Logística)

La Etapa III se integra al dashboard GAC y conserva las etapas anteriores. Todo el trabajo se entrega localmente. No requiere GitHub ni Canvas para ejecutarse.

## Ejecutar

Abre esta carpeta en Visual Studio Code. Usa Python 3.12 y, desde la raíz del proyecto:

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m streamlit run app_univariado.py --server.port 8517
```

En Windows usa `py -3.12 -m venv .venv` y `.venv\Scripts\python.exe` en lugar de `python`. Si 8517 ya está ocupado por el dashboard original, usa `--server.port 8503` para abrir esta copia. No ejecutes simultáneamente ambas carpetas en el mismo puerto.

## Qué clasifica cada modelo

| Caso | Variable dependiente Y | Predictores X | Unidad |
|---|---|---|---|
| Prueba de manejo | PDM: No=0 / Sí=1 | Asesor codificado, día de semana y mes de registro | Registro de Piso |
| Intervención del gerente | Inter Gerente: No=0 / Sí=1 | Asesor codificado, día de semana y mes de registro | Registro de Piso |
| Cita efectiva | Cita efetiva: No=0 / Sí=1 | Producto y origen de captación | Registro de Plazas |
| Conversión mensual | Conversión reportada ≥4%=1; <4%=0 | Total, Efectivos y Ventas del mes anterior | Mes de Leads Reales |

El 4% es una regla didáctica fija para demostrar la transformación dicotómica, no una meta comercial aprobada. Estos son modelos de clasificación; no predicen cuántos leads habrá. Asesor es una categoría administrativa codificada, no una variable para evaluar desempeño laboral. Debe verificarse la asignación inicial antes de cualquier uso operativo.

## Fuentes y preparación

Se reutilizan las fuentes GAC existentes, revisando la limpieza porque la Etapa I sólo preparaba columnas para gráficas. Los originales se conservan intactos. La carpeta `data/clasificacion` contiene los insumos preparados y `preprocesamiento.json` permite auditar las decisiones.

- **Bitácora de Piso:** 234 filas originales; se excluyen 37 sin nombre de cliente para evitar filas de plantilla y registros sin identificación. Quedan 197 registros, 193 grupos por nombre normalizado. PDM tiene 75 Sí y 122 No; intervención, 31 Sí y 166 No. No se borra por compartir características con otro cliente.
- **Plazas:** 1,048,574 filas originales; se retienen 303 con nombre. Para cita efectiva, 9 no tienen objetivo y se excluyen del ajuste: quedan 294, con 26 Sí y 268 No. No se convierte un objetivo faltante en No.
- **Leads Reales:** la fuente original se encontró junto a trabajos anteriores. Se lee el encabezado en la tercera fila y se excluyen resúmenes y notas. Se propaga el año dentro de sus meses, se convierten comas de miles y porcentajes, y se conserva un calendario mensual completo. Hay 29 meses identificados, uno sin valores. Tras el rezago y la disponibilidad del objetivo quedan 27 observaciones. No se usa un mes distante como si fuera el anterior cuando hay un hueco.
- **Duplicados:** sólo filas originales idénticas. Las visitas repetidas de una persona se conservan en el mismo grupo. La normalización de nombres puede juntar homónimos o no detectar variantes, por lo que no sustituye un identificador fiable de CRM.
- **Nulos de X:** categoría SIN_DATO en predictores categóricos; mediana de entrenamiento en numéricos. Los objetivos no se imputan.
- **Dicotomización:** TRUE/FALSE se convierten a 1/0. Cualquier valor no reconocido se trata como faltante. Las categorías de X se convierten en indicadores 0/1 mediante one-hot encoding aprendido sólo en entrenamiento. No se ordenan arbitrariamente los códigos de asesor.
- **Outliers:** los datos 0/1 y las categorías no requieren un recorte numérico. Para el caso mensual se ofrece limitar extremos mediante Q1−1.5×IQR y Q3+1.5×IQR calculados en entrenamiento, después de imputar. Si IQR=0 no se recorta esa variable. Los límites se aplican a prueba sin recalcularse y no se eliminan filas. Es un tratamiento exploratorio, no evidencia de que los extremos sean errores.
- **Fechas de Piso:** formato mes/día/año, consistente con fechas inequívocas como 5/17/2025. Se usan mes y día de semana como categorías.

Ventas y solicitudes de crédito de Piso tienen sólo **cuatro positivos** y no se modelan como objetivos. El balanceo no crea información nueva y no resuelve esa escasez.

## Evaluación y balanceo

Se ajusta `LogisticRegression` con intercepto y regularización L2. Se comparan tres tratamientos sobre exactamente la misma prueba de cada caso:

1. **Reponderación de clases** (inicial): pesos inversamente proporcionales a la frecuencia en entrenamiento. No cambia el número de registros.
2. **Oversampling aleatorio:** repite observaciones minoritarias sólo en entrenamiento hasta igualar los tamaños. No modifica la prueba ni genera clientes nuevos reales.
3. **Sin balanceo:** referencia para observar el efecto del desbalance.

Para registros individuales se toma el primer bloque de una partición de 5 bloques estratificada por clase y agrupada por persona, con semilla 42. El porcentaje de prueba es aproximadamente 20%, no exactamente 20%, porque se conservan los grupos. Es una evaluación retrospectiva; no asegura generalización temporal. Para meses se reservan los últimos 20% (6 meses), con 21 de entrenamiento. Los conteos reales del mes previo se conocen en cada predicción a un paso.

La matriz usa filas reales y columnas predichas, ambas en orden No/Sí. Se muestran exactitud, precisión positiva, sensibilidad positiva, especificidad, F1, exactitud balanceada, ROC-AUC y average precision (resumen de la curva precisión-recall). Se compara además contra predecir siempre la clase mayoritaria de entrenamiento. Si no hay Sí predichos, precisión se reporta como 0 por convención. Si la prueba sólo tiene una clase, ROC-AUC y exactitud balanceada se dejan no disponibles y se advierte que no se puede medir discriminación completa.

El umbral inicial es 0.50 y puede ajustarse para explorar el intercambio entre detección y falsas alarmas. Seleccionarlo después de examinar la prueba convierte esa exploración en validación; se necesita otra muestra independiente para una evaluación final. Las puntuaciones de modelos balanceados no equivalen necesariamente a probabilidades calibradas de la población.

## Resultados iniciales

Reponderación, umbral 0.50, límites IQR activos:

| Caso | Prueba | Exactitud | Precisión | Sensibilidad |
|---|---:|---:|---:|---:|
| Prueba de manejo | 39 | 35.90% | 29.17% | 46.67% |
| Intervención del gerente | 39 | 76.92% | 28.57% | 33.33% |
| Cita efectiva | 58 | 36.21% | 2.94% | 20.00% |
| Conversión mensual ≥4% | 6 | 100% | 100% | 100% |

**El 100% mensual no demuestra buen poder predictivo:** los seis meses de prueba son positivos; no hay negativos para evaluar la capacidad de distinguir ambas clases. No se seleccionó el corte para mejorar las métricas. Se conserva la partición y se documenta la limitación.

En Cita efectiva, sin balanceo, la exactitud es 91.38% pero la sensibilidad es cero: el modelo dice siempre No. La reponderación detecta un positivo en esta prueba a costa de muchas falsas alarmas. Por tanto, no hay evidencia de utilidad operativa en ese caso. Los demás resultados también son exploratorios y tienen pocos positivos de prueba. No deben presentarse como pronósticos comerciales validados ni evidencia causal.

## Archivos y reproducción

- `clasificacion.py`: carga de casos, partición, preprocesamiento, ajuste y métricas.
- `vista_clasificacion.py`: pestañas, heatmaps, boxplots, tablas, selectores, umbral y descargas. Los controles permanecen debajo de los resultados.
- `preparar_clasificacion.py`: reconstruye las tablas a partir de los originales locales; usa `--bases`, `--leads` y `--destino`.
- `Etapa-III-Clasificacion-Logistica.ipynb`: análisis y resultados ejecutables.
- `data/clasificacion/`: Bitacora de Piso.csv, Plazas.csv, Leads Reales.csv y auditoría. Contienen datos preparados; no se hacen pasar por originales.
- `resultados/etapa_iii/`: comparación de los tres tratamientos para cuatro casos, coeficientes, matrices y predicciones iniciales.
- `tests/test_clasificacion.py`: comprueba métricas, exclusión de grupos compartidos, balanceo exclusivo en entrenamiento y ausencia de ajuste con etiquetas de prueba.

```bash
python clasificacion.py
python -m unittest discover -s tests -v
python preparar_clasificacion.py --bases Base_Datos_GAC --leads "Base_Datos_GAC/Leads Reales.csv" --destino data/clasificacion
```

Para ver los notebooks selecciona el entorno Python instalado. Esta carpeta incluye los originales locales para ejecutar también la Etapa I; contienen información de clientes. No se ha publicado ningún archivo ni creado repositorio remoto por instrucción del usuario.

## Referencias

- [Regresión logística y class_weight](https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegression.html)
- [Preprocesamiento y fuga de información](https://scikit-learn.org/stable/common_pitfalls.html)
- [Partición estratificada por grupos](https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.StratifiedGroupKFold.html)
