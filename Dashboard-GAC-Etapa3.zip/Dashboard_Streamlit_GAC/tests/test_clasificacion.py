import unittest
from unittest.mock import patch
import numpy as np
from clasificacion import CASES, METHODS, load_case, split_case, fit_case, evaluate, IQRCapper
from preparar_clasificacion import binary
import pandas as pd

class LogisticTests(unittest.TestCase):
    def test_binary_unknown_and_null_remain_missing(self):
        converted=binary(pd.Series(['TRUE','false','Sí','No',None,'9']))
        self.assertEqual(converted.iloc[:4].tolist(),[1,0,1,0])
        self.assertTrue(converted.iloc[4:].isna().all())
    def test_groups_do_not_overlap(self):
        for case,spec in CASES.items():
            data,_=load_case(case)
            train,test=split_case(data,spec)
            self.assertFalse(set(train.Grupo)&set(test.Grupo))
            if spec['kind']=='mensual': self.assertLess(train.Fecha.max(),test.Fecha.min())
    def test_oversampling_does_not_change_test(self):
        case=list(CASES)[1]
        a,b=fit_case(case,METHODS[1]),fit_case(case,METHODS[2])
        self.assertEqual(a['after'][0],a['after'][1])
        self.assertEqual(a['test'].Registro.tolist(),b['test'].Registro.tolist())
        self.assertEqual(a['test']['Inter Gerente'].tolist(),b['test']['Inter Gerente'].tolist())
    def test_weights_only_from_training(self):
        r=fit_case(list(CASES)[1])
        for c in [0,1]: self.assertAlmostEqual(r['weights'][c],len(r['train'])/(2*r['before'][c]))
    def test_known_confusion_and_metrics(self):
        m,cm,_=evaluate([0,0,1,1],[.1,.8,.2,.9])
        np.testing.assert_array_equal(cm,[[1,1],[1,1]])
        for key in ['Exactitud','Precisión','Sensibilidad']: self.assertAlmostEqual(m[key],.5)
    def test_iqr_learned_without_test_extreme(self):
        cap=IQRCapper().fit(np.arange(20).reshape(-1,1))
        upper=cap.upper_.copy()
        transformed=cap.transform([[1000000]])
        np.testing.assert_array_equal(cap.upper_,upper)
        self.assertEqual(transformed[0,0],upper[0])
    def test_monthly_rezago_uses_previous_calendar_month(self):
        r=fit_case(list(CASES)[-1])
        self.assertEqual(r['frame'].Registro.iloc[0],'2024-03')
        self.assertEqual(r['frame'].Total_anterior.iloc[0],543)
        self.assertTrue(np.isnan(r['metrics']['ROC-AUC']))
    def test_test_target_cannot_change_monthly_fit(self):
        case=list(CASES)[-1]
        a=fit_case(case)
        data,audit=load_case(case)
        changed=data.copy()
        changed.loc[changed.index.isin(a['test'].index),'Conversion_alta']=1-changed.loc[changed.index.isin(a['test'].index),'Conversion_alta']
        with patch('clasificacion.load_case',return_value=(changed,audit)):
            b=fit_case(case)
        np.testing.assert_allclose(a['model'].coef_,b['model'].coef_)
        np.testing.assert_allclose(a['predictions']['Puntuación modelo'],b['predictions']['Puntuación modelo'])

if __name__=='__main__': unittest.main()
