"""Pruebas de integridad temporal y del cálculo de los modelos."""
import unittest
import numpy as np
import pandas as pd
from modelado import load_monthly, supervised, chronological_split, fit_regression, run_analysis, scores


class ModelingTests(unittest.TestCase):
    def test_lag_has_only_previous_month(self):
        raw = load_monthly()
        table = supervised(raw, "Digitales")
        np.testing.assert_array_equal(table["Digitales (t−1)"], raw.Digitales.iloc[:-1])
        np.testing.assert_array_equal(table.Digitales, raw.Digitales.iloc[1:])
        self.assertEqual(len(table), 29)

    def test_chronological_holdout(self):
        train, test = chronological_split(supervised(load_monthly(), "Digitales"))
        self.assertEqual((len(train), len(test)), (23, 6))
        self.assertLess(train.Periodo.max(), test.Periodo.min())
        self.assertEqual(test.Periodo.tolist(), [25, 26, 27, 28, 29, 30])

    def test_training_does_not_use_test_target(self):
        table = supervised(load_monthly(), "Digitales")
        train, test = chronological_split(table)
        a = fit_regression(train, test, "Digitales", ["Piso (t−1)", "Plazas (t−1)"])
        changed = test.copy()
        changed["Digitales"] += 10000
        b = fit_regression(train, changed, "Digitales", ["Piso (t−1)", "Plazas (t−1)"])
        np.testing.assert_allclose(a["model"].coef_, b["model"].coef_)
        np.testing.assert_allclose(a["test_prediction"], b["test_prediction"])

    def test_ols_recovers_known_relationship(self):
        x = np.arange(20, dtype=float)
        table = pd.DataFrame({"Periodo": x + 1, "Digitales": 3 + 2*x, "Piso (t−1)": x})
        a = fit_regression(table.iloc[:15], table.iloc[15:], "Digitales", ["Piso (t−1)"])
        self.assertAlmostEqual(a["model"].coef_[0], 2.)
        self.assertAlmostEqual(a["model"].intercept_, 3.)
        self.assertAlmostEqual(a["test_scores"]["MAE"], 0.)

    def test_scores_and_baseline(self):
        metrics = scores([1, 2, 3], [2, 2, 2])
        self.assertAlmostEqual(metrics["MAE"], 2/3)
        self.assertAlmostEqual(metrics["RMSE"], np.sqrt(2/3))
        self.assertAlmostEqual(metrics["R²"], 0.)
        self.assertTrue(np.isnan(scores([2, 2], [2, 2])["R²"]))
        _, _, test, _, _, pred = run_analysis(load_monthly())
        np.testing.assert_array_equal(pred.Persistencia, test["Digitales (t−1)"])

    def test_rejects_contemporaneous_or_target_as_feature(self):
        train, test = chronological_split(supervised(load_monthly(), "Digitales"))
        with self.assertRaises(ValueError):
            fit_regression(train, test, "Digitales", ["Digitales"])
        with self.assertRaises(ValueError):
            run_analysis(load_monthly(), multiple=["Piso (t−1)"])


if __name__ == "__main__":
    unittest.main()
