"""Interfaz GAC de clasificación logística."""
import json
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from clasificacion import CASES, METHODS, DATA, fit_case

RED, BLUE, GRAY = '#D9082F','#236B8E','#454B57'


def plot(fig,key):
    fig.update_layout(template='plotly_white',paper_bgcolor='white',plot_bgcolor='white',
        font=dict(color='#211C1D'),margin=dict(t=50,b=45,l=25,r=25),height=400)
    st.plotly_chart(fig,width='stretch',theme=None,key=key,config={'displaylogo':False})


@st.cache_data(show_spinner=False)
def cached_fit(case,method,threshold,cap,revision):
    return fit_case(case,method,threshold,cap)


def render_classification():
    st.caption('ETAPA III · MODELADO PREDICTIVO Y CLASIFICACIÓN')
    st.title('Regresión logística')
    st.write('Clasificación de resultados Sí / No en las bases GAC. Compara el balanceo de clases y evalúa los aciertos y errores en datos separados del entrenamiento.')
    results_area=st.container()
    with st.container(border=True):
        st.subheader('Configurar la clasificación')
        a,b=st.columns(2)
        case=a.selectbox('Resultado que se quiere clasificar (Y)',list(CASES))
        method=b.selectbox('Tratamiento del desbalance',METHODS)
        threshold=st.slider('Umbral para clasificar como Sí',.10,.90,.50,.05)
        cap=st.checkbox('Limitar extremos numéricos con IQR de entrenamiento',value=True,
            help='Sólo se aplica al ejemplo mensual. Las variables binarias y las categorías no se recortan.')
        st.caption('El balanceo sólo usa entrenamiento. El umbral inicial es 0.50. Cambiarlo después de ver la prueba es exploración, no una nueva evaluación independiente.')
    with results_area:
        try:
            revision=tuple((p.name,p.stat().st_mtime_ns) for p in DATA.glob('*.csv'))
            r=cached_fit(case,method,threshold,cap,revision)
        except (OSError,ValueError,KeyError) as error:
            st.error(f'No fue posible preparar la clasificación: {error}')
            return
        spec=r['spec']
        st.subheader(case)
        st.write(f"**Y = {spec['target']}** · Clase positiva: **{spec['positive']}**.")
        st.write('**Predictores X:** '+', '.join(spec['features'])+'.')
        st.caption('Asesor_codigo es un identificador categórico sin nombre. Día de semana: 0=lunes, 6=domingo.' if spec['kind']=='piso' else 'Se excluyen del modelo identificadores de clientes, el propio resultado y variables posteriores que podrían revelar el resultado.')
        for col,label,value in zip(st.columns(4),['Registros utilizables','Entrenamiento','Prueba','Sí en prueba'],[len(r['frame']),len(r['train']),len(r['test']),int(r['test'][spec['target']].sum())]):
            col.metric(label,value)
        if spec['kind']=='mensual':
            st.info('Ejemplo mensual: Sí significa conversión reportada ≥ 4%. Es una regla didáctica fija, no una meta validada por GAC. Se utilizan conteos del mes anterior y los últimos 20% de meses como prueba.')
        else:
            st.caption('Partición fija de aproximadamente 80/20, estratificada por clase y agrupada por nombre normalizado antes de anonimizar. Ningún grupo aparece en ambos conjuntos. Es evaluación retrospectiva, no validación temporal de futuros clientes.')
        if r['test'][spec['target']].nunique()<2:
            st.warning('La prueba contiene una sola clase. Incluso una exactitud de 100% no demuestra discriminación entre Sí y No. ROC-AUC y exactitud balanceada no están disponibles; se requieren más meses con ambas clases.')
        elif r['test'][spec['target']].value_counts().min()<10:
            st.warning('Hay menos de 10 ejemplos de una clase en prueba. Las métricas son sensibles a unos pocos casos y deben interpretarse como exploratorias.')
        tabs=st.tabs(['Evaluación','Relaciones y distribución','Preprocesamiento','Comparar balanceo','Método y datos'])
        with tabs[0]:
            for col,metric in zip(st.columns(3),['Exactitud','Precisión','Sensibilidad']):
                col.metric(metric,f"{r['metrics'][metric]:.1%}")
            st.caption('Exactitud: aciertos / total. Precisión: Sí reales / Sí predichos. Sensibilidad: Sí detectados / todos los Sí reales. Si no se predice ningún Sí, se reporta precisión=0 por convención y no como prueba de utilidad.')
            fig=px.imshow(r['matrix'],x=['Predicho No (0)','Predicho Sí (1)'],y=['Real No (0)','Real Sí (1)'],text_auto=True,
                color_continuous_scale=['#FFFFFF',RED],aspect='auto',labels={'color':'Casos'},title='Matriz de confusión · prueba')
            plot(fig,'logistic_matrix')
            tn,fp,fn,tp=r['matrix'].ravel()
            st.write(f'**{tn} verdaderos negativos · {fp} falsos positivos · {fn} falsos negativos · {tp} verdaderos positivos.**')
            metrics=pd.DataFrame([{'Modelo':'Regresión logística',**r['metrics']},{'Modelo':'Siempre la clase mayoritaria de entrenamiento',**r['baseline_metrics']}])
            st.dataframe(metrics,hide_index=True,width='stretch',column_config={c:st.column_config.NumberColumn(format='%.3f') for c in r['metrics']})
            if np.isfinite(r['metrics']['Exactitud balanceada']) and r['metrics']['Exactitud balanceada']<=.5:
                st.warning('La exactitud balanceada no supera 0.50 en esta prueba. Este resultado no respalda un clasificador útil para distinguir ambas clases.')
            scores=r['predictions'].copy()
            scores['Resultado real']=scores.Real.map({0:'No',1:'Sí'})
            plot(px.box(scores,x='Resultado real',y='Puntuación modelo',points='all',color='Resultado real',color_discrete_map={'No':GRAY,'Sí':RED},title='Puntuaciones según resultado real'),'logistic_box')
            st.caption('La salida logística está entre 0 y 1. Con reponderación u oversampling no debe tratarse como una probabilidad real calibrada de la población.')
            st.dataframe(r['predictions'],hide_index=True,width='stretch')
            st.download_button('Descargar predicciones',r['predictions'].to_csv(index=False).encode('utf-8-sig'),'clasificacion_predicciones.csv','text/csv')
        with tabs[1]:
            st.subheader('Asociaciones exploratorias en entrenamiento')
            if spec['kind']=='mensual':
                columns=[*spec['features'],spec['target']]
            else:
                columns=[c for c in ['PDM','Inter Gerente','SDC','Venta','Seguimiento','Cita efetiva'] if c in r['train']]
            corr=r['train'][columns].corr()
            plot(px.imshow(corr,text_auto='.2f',zmin=-1,zmax=1,color_continuous_scale=[BLUE,'white',RED],aspect='auto',title='Correlaciones · sólo entrenamiento'),'logistic_heatmap')
            st.caption('Entre variables binarias, Pearson equivale al coeficiente phi. Este mapa describe asociaciones y no es el ajuste logístico ni demuestra causalidad. Los otros resultados operativos del mapa no se usan como predictores.')
            balance=pd.DataFrame({'Clase':['No','Sí'],'Antes del balanceo':[r['before'][0],r['before'][1]],'Filas para ajuste':[r['after'][0],r['after'][1]],'Peso de clase':[r['weights'][0],r['weights'][1]]})
            st.dataframe(balance,hide_index=True,width='stretch')
            st.caption('Reponderación cambia el peso de los errores, no el número de filas. Oversampling repite observaciones de la clase minoritaria sólo en entrenamiento.')
            st.subheader('Coeficientes del modelo')
            st.dataframe(r['coefficients'].sort_values('Coeficiente',ascending=False),hide_index=True,width='stretch')
            st.caption('Los coeficientes actúan sobre log-odds. Los numéricos están estandarizados; las categorías usan indicadores 0/1 completos con regularización L2, sin categoría de referencia. No interpretar sus odds ratios como comparaciones directas contra una referencia. No se calculan p-valores ni se infieren efectos causales.')
        with tabs[2]:
            audit=json.loads((DATA/'preprocesamiento.json').read_text())
            details=audit[spec['kind']]
            st.write('**Objetivos faltantes:** se excluyen del modelo, nunca se rellenan con No. **Predictores faltantes:** categoría SIN_DATO o mediana aprendida sólo en entrenamiento.')
            st.write('**Transformaciones:** TRUE/FALSE → 1/0; categorías normalizadas y codificadas con indicadores dicotómicos. En Leads Reales se crea Conversion_alta y rezagos de un mes.')
            st.write('**Outliers:** los 0/1 y códigos de categoría no son valores extremos numéricos. Para los conteos mensuales se calculan límites Q1−1.5×IQR y Q3+1.5×IQR sólo con entrenamiento; el ajuste es opcional y no elimina filas.')
            st.dataframe(pd.DataFrame({'Columna':details['nulos'].keys(),'Nulos en tabla preparada':details['nulos'].values()}),hide_index=True,width='stretch')
            st.json({**{k:v for k,v in details.items() if k not in ['nulos','clases']},**r['audit']})
            if 'outliers' in r:
                st.dataframe(r['outliers'],hide_index=True,width='stretch')
            st.caption('Las fechas de Piso se interpretan como mes/día/año, consistente con fechas como 5/17/2025. No se deducen características a partir de nombres, teléfonos ni correos. Agrupar por nombre normalizado evita repeticiones exactas, pero puede juntar homónimos o no detectar variantes de escritura.')
        with tabs[3]:
            st.subheader('Mismo caso y misma prueba, tres tratamientos')
            rows=[]
            for option in METHODS:
                alternative=cached_fit(case,option,threshold,cap,revision)
                rows.append({'Tratamiento':option,**alternative['metrics']})
            comparison=pd.DataFrame(rows)
            st.dataframe(comparison,hide_index=True,width='stretch',column_config={c:st.column_config.NumberColumn(format='%.3f') for c in r['metrics']})
            plot(px.bar(comparison.melt(id_vars='Tratamiento',value_vars=['Exactitud','Precisión','Sensibilidad'],var_name='Métrica',value_name='Valor'),x='Tratamiento',y='Valor',color='Métrica',barmode='group',color_discrete_sequence=[GRAY,BLUE,RED]),'logistic_compare')
            st.write('El balanceo puede aumentar la detección de Sí a costa de más falsas alarmas. No necesariamente mejora todas las métricas. Las comparaciones se limitan al mismo objetivo y conjunto de prueba.')
            st.download_button('Descargar comparación',comparison.to_csv(index=False).encode('utf-8-sig'),'comparacion_logistica.csv','text/csv')
        with tabs[4]:
            st.write('**Modelos incluidos:** prueba de manejo e intervención del gerente (Piso); cita efectiva (Plazas); conversión mensual ≥4% (Leads Reales). Ventas y solicitudes de crédito de Piso tienen sólo cuatro positivos y se excluyen como objetivos de clasificación por insuficiencia de casos.')
            st.write('**Particiones:** individuales, primer bloque de StratifiedGroupKFold con 5 bloques y semilla 42; mensual, últimos 20% de registros válidos. No se elige el bloque por su rendimiento. Los preprocesadores y el balanceo se ajustan exclusivamente en entrenamiento.')
            st.write('**Alcance:** modelos académicos exploratorios. Se debe confirmar que el asesor asignado corresponda al momento inicial antes de usar el modelo en operación. No se utilizan temperatura, estatus, razones de no venta ni resultados simultáneos para anticipar otros resultados. No se evalúa causalidad, calidad individual del asesor ni rentabilidad.')
            st.write('**Meses:** se conserva el calendario de Leads Reales, se eliminan filas resumen y se convierten comas de miles y porcentajes. El objetivo mensual usa la conversión reportada, que está redondeada en origen. Los meses sin objetivo o sin ningún predictor previo quedan fuera. No se imputa la clase.')
            st.dataframe(r['frame'],hide_index=True,width='stretch')
            st.caption('Tabla preparada sin nombres ni datos de contacto. Los códigos de grupo sólo sirven para impedir que visitas repetidas se repartan entre entrenamiento y prueba.')
            st.markdown('[Regresión logística y pesos de clase](https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegression.html) · [Prevención de fuga de información](https://scikit-learn.org/stable/common_pitfalls.html)')
