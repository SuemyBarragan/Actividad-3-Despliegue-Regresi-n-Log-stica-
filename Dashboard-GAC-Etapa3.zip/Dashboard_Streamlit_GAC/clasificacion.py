"""Etapa III: regresión logística reproducible sin preprocesar con datos de prueba."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score, f1_score, balanced_accuracy_score, roc_auc_score, average_precision_score

ROOT = Path(__file__).parent
DATA = ROOT/'data'/'clasificacion'
CASES = {
    'Prueba de manejo · Piso': {'file':'Bitacora de Piso.csv','target':'PDM','features':['Asesor_codigo','Dia_semana','Mes'],'kind':'piso','positive':'Sí realizó prueba de manejo'},
    'Intervención del gerente · Piso': {'file':'Bitacora de Piso.csv','target':'Inter Gerente','features':['Asesor_codigo','Dia_semana','Mes'],'kind':'piso','positive':'Sí hubo intervención del gerente'},
    'Cita efectiva · Plazas': {'file':'Plazas.csv','target':'Cita efetiva','features':['Producto','Origen'],'kind':'plazas','positive':'Sí hubo cita efectiva'},
    'Conversión mensual ≥ 4% · Leads Reales': {'file':'Leads Reales.csv','target':'Conversion_alta','features':['Total_anterior','Efectivos_anterior','Ventas_anterior'],'kind':'mensual','positive':'Tasa mensual de conversión reportada ≥ 4%'},
}
METHODS = ['Reponderación de clases','Oversampling','Sin balanceo']

class IQRCapper(BaseEstimator, TransformerMixin):
    """Límites estimados sólo en entrenamiento; conserva extremos si IQR=0."""
    def __init__(self, enabled=True): self.enabled=enabled
    def fit(self, X, y=None):
        a=np.asarray(X,dtype=float)
        q1,q3=np.nanpercentile(a,[25,75],axis=0)
        spread=q3-q1
        self.lower_=np.where((spread>0)&self.enabled,q1-1.5*spread,-np.inf)
        self.upper_=np.where((spread>0)&self.enabled,q3+1.5*spread,np.inf)
        return self
    def transform(self,X): return np.clip(np.asarray(X,dtype=float),self.lower_,self.upper_)
    def get_feature_names_out(self,input_features=None): return np.asarray(input_features,dtype=object)


def load_case(case):
    spec=CASES[case]
    raw=pd.read_csv(DATA/spec['file'])
    if spec['kind']=='mensual':
        raw['Fecha']=pd.to_datetime(raw.Fecha)
        if raw.Fecha.duplicated().any(): raise ValueError('Hay meses duplicados en Leads Reales.')
        raw=raw.set_index('Fecha').sort_index().asfreq('MS').reset_index()
        for name in ['Total','Efectivos','Ventas']:
            raw[name+'_anterior']=raw[name].shift(1)
        raw['Conversion_alta']=np.where(raw.Conversion.notna(),(raw.Conversion>=4).astype(float),np.nan)
        raw['Registro']=raw.Fecha.dt.strftime('%Y-%m')
        raw['Grupo']=raw.Registro
        valid=raw.Conversion_alta.notna() & raw[spec['features']].notna().any(axis=1)
    else:
        valid=raw[spec['target']].isin([0,1])
        for feature in spec['features']:
            raw[feature]=raw[feature].map(lambda x:str(x) if pd.notna(x) else np.nan)
    frame=raw[valid].reset_index(drop=True)
    frame[spec['target']]=frame[spec['target']].astype(int)
    return frame, {'filas_fuente_preparada':len(raw),'filas_excluidas_objetivo_o_rezago':int((~valid).sum())}


def split_case(frame,spec):
    if spec['kind']=='mensual':
        cut=len(frame)-int(np.ceil(len(frame)*.2))
        train,test=np.arange(cut),np.arange(cut,len(frame))
    else:
        # No se reparten visitas de una misma persona entre entrenamiento y prueba.
        splitter=StratifiedGroupKFold(n_splits=5,shuffle=True,random_state=42)
        train,test=next(splitter.split(frame,frame[spec['target']],frame.Grupo))
    if frame.iloc[train][spec['target']].nunique()!=2:
        raise ValueError('Entrenamiento requiere las dos clases. No se puede ajustar este caso.')
    if set(frame.iloc[train].Grupo)&set(frame.iloc[test].Grupo):
        raise ValueError('Una misma persona aparece en entrenamiento y prueba.')
    return frame.iloc[train].copy(),frame.iloc[test].copy()


def evaluate(y,probability,threshold=.5):
    y=np.asarray(y,dtype=int)
    predicted=(np.asarray(probability)>=threshold).astype(int)
    tn,fp,fn,tp=confusion_matrix(y,predicted,labels=[0,1]).ravel()
    metrics={'Exactitud':accuracy_score(y,predicted),
        'Precisión':precision_score(y,predicted,zero_division=0),
        'Sensibilidad':recall_score(y,predicted,zero_division=0),
        'Especificidad':tn/(tn+fp) if tn+fp else np.nan,
        'F1':f1_score(y,predicted,zero_division=0),
        'Exactitud balanceada':balanced_accuracy_score(y,predicted) if len(np.unique(y))==2 else np.nan,
        'ROC-AUC':roc_auc_score(y,probability) if len(np.unique(y))==2 else np.nan,
        'PR-AUC (AP)':average_precision_score(y,probability) if len(np.unique(y))==2 else np.nan}
    return metrics, np.array([[tn,fp],[fn,tp]]), predicted


def fit_case(case,method=METHODS[0],threshold=.5,cap_outliers=True):
    if method not in METHODS or not 0<threshold<1: raise ValueError('Configuración inválida.')
    spec=CASES[case]
    frame,audit=load_case(case)
    train,test=split_case(frame,spec)
    Xtrain,Xtest=train[spec['features']],test[spec['features']]
    ytrain,ytest=train[spec['target']],test[spec['target']]
    if spec['kind']=='mensual':
        preprocessing=Pipeline([('imputar',SimpleImputer(strategy='median',keep_empty_features=True)),
            ('extremos',IQRCapper(cap_outliers)),('escalar',StandardScaler())])
    else:
        preprocessing=Pipeline([('imputar',SimpleImputer(strategy='constant',fill_value='SIN_DATO')),
            ('dicotomizar',OneHotEncoder(handle_unknown='ignore',sparse_output=False,drop=None))])
    X=preprocessing.fit_transform(Xtrain)
    Z=preprocessing.transform(Xtest)
    original_counts=ytrain.value_counts().reindex([0,1],fill_value=0)
    yfit=ytrain.to_numpy()
    Xfit=X
    if method=='Oversampling':
        rng=np.random.default_rng(42)
        majority=int(original_counts.max())
        indexes=np.concatenate([rng.choice(np.flatnonzero(yfit==c),size=majority,replace=(original_counts[c]<majority)) for c in [0,1]])
        Xfit,yfit=X[indexes],yfit[indexes]
    model=LogisticRegression(class_weight='balanced' if method==METHODS[0] else None,max_iter=2000,random_state=42)
    model.fit(Xfit,yfit)
    probability=model.predict_proba(Z)[:,1]
    metrics,matrix,predicted=evaluate(ytest,probability,threshold)
    majority=int(ytrain.mode().iloc[0])
    baseline_metrics,baseline_matrix,_=evaluate(ytest,np.full(len(ytest),majority),.5)
    coefficients=pd.DataFrame({'Variable':preprocessing.get_feature_names_out(spec['features']),
        'Coeficiente':model.coef_[0], 'Odds ratio':np.exp(np.clip(model.coef_[0],-700,700))})
    before=original_counts.to_dict()
    after=pd.Series(yfit).value_counts().reindex([0,1],fill_value=0).to_dict()
    predictions=pd.DataFrame({'Registro':test.Registro,'Real':ytest,'Puntuación modelo':probability,
        'Predicho':predicted}).reset_index(drop=True)
    result={'case':case,'spec':spec,'frame':frame,'train':train,'test':test,'audit':audit,
        'preprocessing':preprocessing,'model':model,'metrics':metrics,'matrix':matrix,
        'baseline_metrics':baseline_metrics,'baseline_matrix':baseline_matrix,'predictions':predictions,
        'coefficients':coefficients,'before':before,'after':after,'threshold':threshold,'method':method,
        'weights':{c:len(ytrain)/(2*int(original_counts[c])) for c in [0,1]} if method==METHODS[0] else {0:1.,1:1.}}
    if spec['kind']=='mensual':
        imputed=preprocessing.named_steps['imputar'].transform(Xtrain)
        caps=preprocessing.named_steps['extremos']
        result['outliers']=pd.DataFrame({'Variable':spec['features'],'Límite inferior':caps.lower_,'Límite superior':caps.upper_,
            'Valores ajustados en entrenamiento':((imputed<caps.lower_)|(imputed>caps.upper_)).sum(axis=0)})
    return result


def export_results(destination=None):
    destination=Path(destination or ROOT/'resultados'/'etapa_iii')
    destination.mkdir(parents=True,exist_ok=True)
    rows=[]
    for i,case in enumerate(CASES,1):
        for method in METHODS:
            r=fit_case(case,method)
            rows.append({'Caso':case,'Método':method,'N entrenamiento':len(r['train']),'N prueba':len(r['test']),**r['metrics']})
            if method==METHODS[0]:
                r['predictions'].to_csv(destination/f'caso_{i}_predicciones.csv',index=False)
                r['coefficients'].to_csv(destination/f'caso_{i}_coeficientes.csv',index=False)
                pd.DataFrame(r['matrix'],index=['Real No','Real Sí'],columns=['Predicho No','Predicho Sí']).to_csv(destination/f'caso_{i}_matriz.csv')
    comparison=pd.DataFrame(rows)
    comparison.to_csv(destination/'comparacion_modelos.csv',index=False)
    return comparison

if __name__=='__main__': print(export_results().to_string(index=False))
