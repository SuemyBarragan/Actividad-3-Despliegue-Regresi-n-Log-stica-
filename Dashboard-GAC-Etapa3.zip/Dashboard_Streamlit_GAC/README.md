# Actividad 3 (Despliegue de Regresión Logística)

Dashboard local GAC con las Etapas I, II y III. La nueva Etapa III incluye cuatro casos de clasificación logística, reponderación, oversampling, matrices de confusión y métricas.

- [Guía completa de la Etapa III](ACTIVIDAD_3.md): variables, preparación, evaluación y limitaciones.
- [Notebook de la Etapa III](Etapa-III-Clasificacion-Logistica.ipynb): análisis ejecutado con resultados.
- [Guía de las etapas anteriores](GUIA_ETAPAS_I_II.md).

## Iniciar desde esta carpeta

Con Python 3.12 instalado:

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m streamlit run app_univariado.py --server.port 8503
```

En Windows, usa `py -3.12 -m venv .venv` y `.venv\Scripts\python.exe` en los comandos de instalación y ejecución. Abre http://localhost:8503. Se usa 8503 para esta copia; el dashboard original integrado continúa en 8517. La configuración de depuración de VS Code también está disponible.

Los controles están debajo de los resultados. Selecciona **III · Clasificación logística** en la barra lateral. Las tablas preparadas están en `data/clasificacion`; los originales locales están en `Base_Datos_GAC`. Las fuentes con nombres o contactos no se han publicado.

## Verificar y regenerar resultados

```bash
python -m unittest discover -s tests -v
python clasificacion.py
```

Todo el trabajo se conserva localmente. No se creó ni publicó ningún repositorio remoto ni se realizó una entrega en Canvas.
