"""Extrae tablas sin nombres ni contactos; los originales permanecen locales."""
from pathlib import Path
import json
import unicodedata
import pandas as pd


def normalize(value):
    if pd.isna(value) or not str(value).strip():
        return pd.NA
    text = unicodedata.normalize('NFKD', str(value).strip().upper())
    return ' '.join(''.join(c for c in text if not unicodedata.combining(c)).split())


def binary(series):
    return series.map(normalize).map({'TRUE': 1, 'FALSE': 0, 'SI': 1, 'NO': 0, '1': 1, '0': 0}).astype('Float64')


def prepare(base_dir, leads_path, destination):
    base_dir, destination = Path(base_dir), Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    reports = {}
    for kind, name, date_col, source_name, targets in [
        ('piso','Nombre Cliente','Fecha','Bitacora de Piso',['PDM','Inter Gerente','SDC','Venta']),
        ('plazas','Nombre','Fecha Origen','Plazas',['Seguimiento','Cita efetiva','PDM','SDC']),
    ]:
        path = base_dir / f'Analisis GAC Full7agosto 2026({source_name}).csv'
        raw = pd.read_csv(path, dtype='string')
        raw.columns = raw.columns.str.strip()
        for column in raw:
            raw[column] = raw[column].str.strip().replace('', pd.NA)
        n_raw = len(raw)
        valid = raw[name].notna()
        frame = raw[valid].copy()
        # Elimina sólo duplicados exactos, no personas con visitas diferentes.
        comparable = [c for c in frame if not c.startswith('Unnamed:')]
        n_before = len(frame)
        frame = frame.drop_duplicates(subset=comparable)
        normalized_names = frame[name].map(normalize)
        groups = pd.factorize(normalized_names)[0]
        dates = pd.to_datetime(frame[date_col], format='mixed', dayfirst=False, errors='coerce')
        out = pd.DataFrame(index=frame.index)
        out['Grupo'] = [f'{kind}_{i:04d}' for i in groups]
        out['Registro'] = [f'{kind}_fila_{i+2}' for i in frame.index]
        if kind == 'piso':
            advisor = frame['Asesor'].map(normalize)
            codes = pd.factorize(advisor)[0]
            out['Asesor_codigo'] = [f'A{i:03d}' if i >= 0 else pd.NA for i in codes]
            out['Dia_semana'] = dates.dt.dayofweek.map(lambda x: str(int(x)) if pd.notna(x) else pd.NA)
            out['Mes'] = dates.dt.month.map(lambda x: str(int(x)) if pd.notna(x) else pd.NA)
        else:
            out['Producto'] = frame.Producto.map(normalize)
            out['Origen'] = frame.Origen.map(normalize)
        invalid = {}
        for target in targets:
            out[target] = binary(frame[target])
            invalid[target] = int((frame[target].notna() & out[target].isna()).sum())
        filename = 'Bitacora de Piso.csv' if kind == 'piso' else 'Plazas.csv'
        out.to_csv(destination/filename, index=False)
        reports[kind] = {'fuente':path.name, 'filas_originales':n_raw,
            'filas_sin_nombre_excluidas':int((~valid).sum()), 'duplicados_exactos_excluidos':n_before-len(frame),
            'filas_preparadas':len(out), 'grupos':out.Grupo.nunique(), 'fechas_no_interpretables':int(dates.isna().sum()),
            'nulos':out.isna().sum().to_dict(), 'binarios_invalidos':invalid,
            'clases':{t:{str(k):int(v) for k,v in out[t].value_counts(dropna=False).items()} for t in targets}}
    raw = pd.read_csv(leads_path, header=2, dtype='string')
    raw.columns = raw.columns.str.strip()
    months = {normalize(m):i+1 for i,m in enumerate(['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'])}
    raw['Año'] = pd.to_numeric(raw['Año'],errors='coerce').ffill()
    raw['Mes_num'] = raw.Mes.map(normalize).map(months)
    monthly = raw[raw.Mes_num.notna() & raw['Año'].notna()].copy()
    monthly['Fecha'] = pd.to_datetime(dict(year=monthly['Año'],month=monthly.Mes_num,day=1))
    cols = ['Total','Efectivos','Ventas','Conversion']
    for c in cols:
        monthly[c] = pd.to_numeric(monthly[c].str.replace(',','',regex=False).str.replace('%','',regex=False),errors='coerce')
        monthly.loc[monthly[c] < 0,c] = float('nan')
    monthly.loc[monthly.Conversion > 100,'Conversion'] = float('nan')
    monthly = monthly.sort_values('Fecha')
    out = monthly[['Fecha',*cols]].copy()
    out.to_csv(destination/'Leads Reales.csv',index=False)
    reports['mensual'] = {'fuente':Path(leads_path).name,'filas_originales':len(raw),'meses_identificados':len(out),
        'nulos':out.isna().sum().to_dict(),'regla_conversion':'Sí = Conversion >= 4%; regla didáctica fija, no meta de negocio validada.',
        'regla_rezago':'Se conserva el calendario completo. No se unen artificialmente meses separados por un faltante.'}
    (destination/'preprocesamiento.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2)+'\n')
    return reports

if __name__ == '__main__':
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('--bases', required=True)
    parser.add_argument('--leads', required=True)
    parser.add_argument('--destino', default='data/clasificacion')
    args=parser.parse_args()
    print(json.dumps(prepare(args.bases,args.leads,args.destino),ensure_ascii=False,indent=2))
